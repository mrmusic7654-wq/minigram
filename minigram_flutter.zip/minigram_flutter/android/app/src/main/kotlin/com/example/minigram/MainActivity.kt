package com.example.minigram

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
    // Empty - Flutter handles everything
}